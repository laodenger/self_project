from PyPDF2 import PdfReader
from langchain_core.prompts import PromptTemplate
from langchain.embeddings import HuggingFaceEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain.chains import RetrievalQA
from langchain.llms import  HuggingFacePipeline
from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
import torch

# 检查CUDA是否可用
if torch.cuda.is_available():
    print("CUDA is available! Training on GPU ...")
    device = torch.device("cuda")  # 设置设备为GPU
else:
    print("CUDA is not available! Training on CPU ...")
    device = torch.device("cpu")  # 设置设备为CPU

# 在此之后，你可以将你的模型和数据移动到指定的设备上（GPU或CPU）
# 例如：model.to(device)
#       data = data.to(device)
#path="F:/llama2"
path="E:/llama2-13b-chat"
DB_FAISS_PATH= 'vectorstore/db_faiss'
custom_prompt_template = """请全程用中文回答,你是一个旅游向导，
Context:{context}
Question:{question}

你的回答:
"""


def create_vector_db():
    doc_reader = PdfReader('南京.pdf')  # L
    raw_text = ''
    for i, page in enumerate(doc_reader.pages):  # 遍历每一页
        text = page.extract_text()
        if text:
            raw_text += text
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    raw_text = [raw_text]
    texts = text_splitter.create_documents(raw_text)
    print(len(texts))
    embeddings = HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2',
                                       model_kwargs={'device': 'cuda' if torch.cuda.is_available() else 'cpu'})
    # embeddings=SentenceTransformer('all-MiniLM-L6-v2')
    # print(embeddings)
    db = FAISS.from_documents(texts, embeddings)
    db.save_local(DB_FAISS_PATH)

def load_llm():
    #tokenizer=AutoTokenizer.from_pretrained(path,trust_remote_code=True)
    #model=AutoModelForCausalLM.from_pretrained(path,torch_dtype=torch.float16,trust_remote_code=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = AutoModelForCausalLM.from_pretrained(path, torch_dtype=torch.float16, trust_remote_code=True).to(device)
    tokenizer = AutoTokenizer.from_pretrained(path, trust_remote_code=True)
    '''
    param_config={"input_ids":input_ids,"max_new_tokens":512,"do_sample":True,"top_p":0.95,
                  "temperature":0.6,"top_k":5,"repetition_penalty":1.3}
    result=llm.generate(**param_config)
    answer=tokenizer.decode(result[0],skip_special_tokens=True)
    print(answer)
    '''
    pipe = pipeline(
        "text-generation",
        model=model,
        tokenizer=tokenizer,
        max_new_tokens=512,
        temperature=0.5
    )
    llm = HuggingFacePipeline(pipeline=pipe)
    return llm

#create_vector_db()
embeddings = HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2',
                                      model_kwargs={'device': 'cuda' if torch.cuda.is_available() else 'cpu'})
prompt = PromptTemplate(template=custom_prompt_template, input_variables=['context', 'question'])
db = FAISS.load_local(DB_FAISS_PATH, embeddings, allow_dangerous_deserialization=True)
llm = load_llm()
qa_chain = RetrievalQA.from_chain_type(llm, chain_type="stuff",
                                           retriever=db.as_retriever(search_kwargs={'k': 3}),
                                       return_source_documents=True, chain_type_kwargs={'prompt': prompt})

def final_result(query):
    response = qa_chain({'query': query})
    print('b')
    return response


#query = "介绍一下南京博物院"
for i in range(10):
    query = input(str("请输入您的问题:"))

    with open("输出.txt", "a", encoding='utf-8') as f:
        print(final_result(query)['context'])
        print(final_result(query))
        f.write("人类:",query,'\n')
        f.write("AI:",final_result(query)['context'],'\n')  # ████████
