from lxml import etree
import requests
import csv
import pandas as pd
from fake_useragent import UserAgent
import os
import re
import xlsxwriter
import requests
from bs4 import BeautifulSoup
headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0'
        , 'cookie': 's_pcqq_liaotianjilu_yindao'
        , 'Host': 'http://www.njlyw.cn'
        , 'Connection': 'keep-alive'}
def pa(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0'
        , 'cookie': 's_pcqq_liaotianjilu_yindao'
        , 'Host': 'http://www.njlyw.cn'
        , 'Connection': 'keep-alive'}
    resp = requests.get(url, headers)
    print(resp)
    text = resp.content.decode('utf-8')
    html = etree.HTML(text)
    price = html.xpath('//*[@id="scenicheadright"]/ul[1]/li/text()')
    time = html.xpath('//*[@id="scenicheadright"]/ul[2]/li/text()')
    call = html.xpath('//*[@id="scenicheadright"]/ul[3]/li/text()')
    traffic = html.xpath('//*[@id="scenicheadright"]/ul[4]/li/text()')
    location = html.xpath('//*[@id="scenicheadright"]/ul[5]/li/text()')
    introduction = html.xpath('//*[@id="scenic_detail"]/div[2]/div/p//text()')
    data_list = []
    data_list.extend(price)
    data_list.extend(time)
    data_list.extend(call)
    data_list.extend(traffic)
    data_list.extend(location)
    data_list.extend(introduction)

    with open('南京.txt', 'a', encoding="utf-8") as f:
        for item in data_list:
            f.write(item.strip())
        f.close()

url = 'http://www.njlyw.cn/websitenew/web/Scenic?m=173&p=8'
pattern = re.compile(r'/websitenew/web/ScenicDetail\?m=173&c=(.*)')
url1='http://www.njlyw.cn/websitenew/web/ScenicDetail?m=173&c='
respt=requests.get(url,headers)
match = pattern.findall(respt.text)
match1 = [value.replace('" target="_blank">\r', '') for value in match]
for i in match1:
    pa(url1+i)
