'''import socket

# 定义主机和端口
HOST = '127.0.0.1'  # 根据你的需求修改主机地址
PORT = 8080  # 根据你的需求修改端口号

# 创建 socket 对象
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 绑定主机和端口
server_socket.bind((HOST, PORT))

# 监听连接
server_socket.listen(1)

print(f"等待连接在 {HOST}:{PORT} ...")

# 接受连接
client_socket, client_address = server_socket.accept()
print(f"连接来自: {client_address}")

while True:
    # 接收来自浏览器的数据
    data = client_socket.recv(1024)
    if not data:
        break
    # 将接收到的数据在终端中输出
    print("收到的数据:", data.decode('utf-8'))

# 关闭连接
client_socket.close()
server_socket.close()'''
import socket

# 定义主机和端口
HOST = '127.0.0.1'  # 根据你的需求修改主机地址
PORT = 8080  # 根据你的需求修改端口号

# 创建 socket 对象
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 绑定主机和端口
server_socket.bind((HOST, PORT))

# 监听连接
server_socket.listen(1)

print(f"等待连接在 {HOST}:{PORT} ...")

# 接受连接
client_socket, client_address = server_socket.accept()
print(f"连接来自: {client_address}")

while True:
    # 接收来自浏览器的数据
    data = client_socket.recv(1024)
    if not data:
        break
    # 将接收到的数据在终端中输出
    decoded_data = data.decode('utf-8')
    # 利用换行符分割数据，假设问题在第一行
    lines = decoded_data.split('\n')
    question = lines[-1]  # 第一行是问题
    print("收到的问题:", question)

# 关闭连接
client_socket.close()
server_socket.close()
