import os
from PyPDF2 import PdfReader
from langchain_core.prompts import PromptTemplate
from langchain.embeddings import HuggingFaceEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain.chains import RetrievalQA
from langchain.llms import  HuggingFacePipeline
from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
import torch
from langchain_core.prompts import PromptTemplate
from langchain_community.llms import OpenAI
from langchain.chains import RetrievalQA
from langchain import LLMChain
os.environ["OPENAI_API_KEY"]="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"
os.environ["SERPAPI_API_KEY"]="f5c0de3ee30d62f92e857dc2017b2b1919077e0307ca787379b545cb77a7ae3b"
from PyPDF2 import PdfReader
from langchain.embeddings import OpenAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain.memory import ConversationBufferMemory
from langchain.agents import load_tools,initialize_agent,AgentType,Tool
import socket
def llama2():
    # 检查CUDA是否可用
    if torch.cuda.is_available():
        print("CUDA is available! Training on GPU ...")
        device = torch.device("cuda")  # 设置设备为GPU
    else:
        print("CUDA is not available! Training on CPU ...")
        device = torch.device("cpu")  # 设置设备为CPU

    # 在此之后，你可以将你的模型和数据移动到指定的设备上（GPU或CPU）
    # 例如：model.to(device)
    #       data = data.to(device)
    # path="F:/llama2"
    path = "E:/llama2-13b-chat"
    DB_FAISS_PATH = 'vectorstore/db_faiss'
    custom_prompt_template = """请全程用中文回答,你是一个旅游向导，
    Context:{context}
    Question:{question}

    你的回答:
    """

    def create_vector_db():
        doc_reader = PdfReader('南京.pdf')  # L
        raw_text = ''
        for i, page in enumerate(doc_reader.pages):  # 遍历每一页
            text = page.extract_text()
            if text:
                raw_text += text
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
        raw_text = [raw_text]
        texts = text_splitter.create_documents(raw_text)
        print(len(texts))
        embeddings = HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2',
                                           model_kwargs={'device': 'cuda' if torch.cuda.is_available() else 'cpu'})
        # embeddings=SentenceTransformer('all-MiniLM-L6-v2')
        # print(embeddings)
        db = FAISS.from_documents(texts, embeddings)
        db.save_local(DB_FAISS_PATH)

    def load_llm():
        # tokenizer=AutoTokenizer.from_pretrained(path,trust_remote_code=True)
        # model=AutoModelForCausalLM.from_pretrained(path,torch_dtype=torch.float16,trust_remote_code=True)
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model = AutoModelForCausalLM.from_pretrained(path, torch_dtype=torch.float16, trust_remote_code=True).to(device)
        tokenizer = AutoTokenizer.from_pretrained(path, trust_remote_code=True)
        '''
        param_config={"input_ids":input_ids,"max_new_tokens":512,"do_sample":True,"top_p":0.95,
                      "temperature":0.6,"top_k":5,"repetition_penalty":1.3}
        result=llm.generate(**param_config)
        answer=tokenizer.decode(result[0],skip_special_tokens=True)
        print(answer)
        '''
        pipe = pipeline(
            "text-generation",
            model=model,
            tokenizer=tokenizer,
            max_new_tokens=512,
            temperature=0.5
        )
        llm = HuggingFacePipeline(pipeline=pipe)
        return llm

    # create_vector_db()
    embeddings = HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2',
                                       model_kwargs={'device': 'cuda' if torch.cuda.is_available() else 'cpu'})
    prompt = PromptTemplate(template=custom_prompt_template, input_variables=['context', 'question'])
    db = FAISS.load_local(DB_FAISS_PATH, embeddings, allow_dangerous_deserialization=True)
    llm = load_llm()
    qa_chain = RetrievalQA.from_chain_type(llm, chain_type="stuff",
                                           retriever=db.as_retriever(search_kwargs={'k': 3}),
                                           return_source_documents=True, chain_type_kwargs={'prompt': prompt})

    def final_result(query):
        response = qa_chain({'query': query})
        print('b')
        return response

    # query = "介绍一下南京博物院"
    for i in range(10):
        query = input(str("请输入您的问题:"))

        with open("输出.txt", "a", encoding='utf-8') as f:
            print(final_result(query)['context'])
            print(final_result(query))
            f.write("人类:", query, '\n')
            f.write("AI:", final_result(query)['context'], '\n')  # ████████


# 定义主机和端口
HOST = '127.0.0.1'  # 根据你的需求修改主机地址
PORT = 8080  # 根据你的需求修改端口号

# 创建 socket 对象
'''server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 绑定主机和端口
server_socket.bind((HOST, PORT))

# 监听连接
server_socket.listen(1)

print(f"等待连接在 {HOST}:{PORT} ...")

# 接受连接
client_socket, client_address = server_socket.accept()
print(f"连接来自: {client_address}")'''

template='''请全程用中文回答,问题是{query}'''
prompt=PromptTemplate(template=template,input_variables=["query"])

memory=ConversationBufferMemory(input_key="history")

doc_reader=PdfReader('南京1.pdf')#L
raw_text=''
for i,page in enumerate(doc_reader.pages):#遍历每一页
    text=page.extract_text()
    if text:
        raw_text+=text
text_splitter=RecursiveCharacterTextSplitter(chunk_size=500,chunk_overlap=60,length_function=len)
texts=text_splitter.split_text(raw_text)#D,切割
embeddings=OpenAIEmbeddings()
docsearch=FAISS.from_texts(texts,embeddings)#V
retriever = docsearch.as_retriever(search_type="similarity", search_kwargs={"k": 4})# R
raq = RetrievalQA.from_chain_type(llm=OpenAI(), retriever=retriever, memory=memory)
rraq=[Tool(name="qa chain",func=raq.run,description="qa chain tool")]
tools=load_tools(["serpapi"])
agent=initialize_agent(tools=rraq,llm=OpenAI(),agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,verbose=True,memory=memory)
for i in range(10):
    # 创建 socket 对象
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # 绑定主机和端口
    server_socket.bind((HOST, PORT))
    # 监听连接
    server_socket.listen(1)
    print(f"等待连接在 {HOST}:{PORT} ...")
    # 接受连接
    client_socket, client_address = server_socket.accept()
    print(f"连接来自: {client_address}")
    #print("请输入你的问题:")
    #query2 = input(str())
    data = client_socket.recv(1024)
    decoded_data=data.decode('utf-8')
    lines = decoded_data.split('\n')
    question = lines[-1]
    if not data:
        break
    # 将接收到的数据在终端中输出
    print("可以问问题了")
    query2=question
    print(query2)
    history = ""
    fprompt = prompt.format(query=query2, history=history)
    # llm_chain = LLMChain(llm=OpenAI(), prompt=prompt)
    #with open("输出.txt", "a", encoding='utf-8') as f:
    with open("C:/Users/梁/Desktop/2/2/web/tour/file.txt", "w", encoding='utf-8') as f:
        inputs = {"input": fprompt}
        result=agent.run(**inputs)
        f.write(f":{result} \n")
        with open("C:/Users/梁/Desktop/2/2/web/tour/public/example.txt", "a", encoding='utf-8') as fa:
            fa.write(f"人类: {query2} \n")
            fa.write(f"AI: {result} \n")
# 关闭连接
client_socket.close()
server_socket.close()