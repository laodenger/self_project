k=input(str())
l=k.split(' ')
a=True
if(len(l)>=1 and len(l)<=10000):
    for i in range(len(l)):
        if (len(l[i]) <= 10 and len(l[i]) >= 1):
            if(len(l)==3):
                if (l[i] == l[i + 1] == l[i + 2]):
                    print(l[i], end=' ')
                    a = False
                    break
            if (i == len(l) - 3):

                if (l[i] == l[i + 1] == l[i + 2] and l[i] != l[i - 1]):
                    print(l[i], end=' ')
                    a = False

            if (i < len(l) - 3):
                if (l[i] == l[i + 1] == l[i + 2] and l[i] != l[i + 3] and l[i] != l[i - 1]):
                    print(l[i], end=' ')
                    a = False

if a:
    print('oops')
